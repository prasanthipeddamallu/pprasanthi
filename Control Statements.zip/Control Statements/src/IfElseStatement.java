
public class IfElseStatement {
	public static void main(String[] args) {  
	   
	    int number=13;  
	     
	    if(number%2==0){  
	        System.out.println("even number");  
	    }else{  
	        System.out.println("odd number");  
	    }  
	}  
}
