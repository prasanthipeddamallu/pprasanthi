
abstract class Bird{
   
   public abstract void sound();
}

public class sparrow extends Bird{

   public void sound(){
	System.out.println("Woof");
   }
   public static void main(String args[]){
	Bird obj = new sparrow();
	obj.sound();
   }
}

