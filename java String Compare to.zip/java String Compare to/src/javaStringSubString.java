
public class javaStringSubString {
	 
		public static void main(String args[]){  
		String s1="javatpoint";  
		System.out.println(s1.substring(2,4));//returns va  
		System.out.println(s1.substring(2));//returns vatpoint  
		}}  

